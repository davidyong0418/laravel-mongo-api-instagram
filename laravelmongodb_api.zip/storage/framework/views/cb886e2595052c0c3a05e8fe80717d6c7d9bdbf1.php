Hello, <?php echo e($first_name); ?> <?php echo e($last_name); ?>

This is confirmation message for signup.

please click this.
your confirmation is 
<?php echo e($confirmation); ?>.
<br>

