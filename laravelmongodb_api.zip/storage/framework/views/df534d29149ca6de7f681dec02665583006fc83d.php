Hello, <?php echo e($username); ?>


Your password is new setted.

This is a new password.
<?php echo e($new_password); ?>

