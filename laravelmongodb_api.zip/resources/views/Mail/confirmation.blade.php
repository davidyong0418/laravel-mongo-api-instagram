Hello, {{$first_name}} {{$last_name}}
This is confirmation message for signup.

please click this.
your confirmation is 
{{$confirmation}}.
<br>

