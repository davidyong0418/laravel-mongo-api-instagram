Hello, {{$username}}

Your password is new setted.

This is a new password.
{{$new_password}}
